import logging
import uuid
from datetime import datetime, timezone

from sentinel_edge.camera.stream import CameraStream
from sentinel_edge.config import load_config
from sentinel_edge.inference.detector import VehicleTracker
from sentinel_edge.logging_config import setup_logging
from sentinel_edge.tracking.state import TrackStateManager
from sentinel_edge.transport.event_client import EventClient

from sentinel_edge.behavior.engine import BehaviorEngine
from sentinel_edge.behavior.rules import BehaviorConfig

from sentinel_edge.decision.engine import DecisionEngine
from sentinel_edge.decision.rules import DecisionConfig


logger = logging.getLogger("sentinel.edge")


# ============================================================
# EVENT BUILDER
# ============================================================

def build_event(
    camera,
    config,
    event_type: str,
    detections: list[dict],
    frame_number: int,
    latency_ms: float,
    metadata_extra: dict | None = None,
) -> dict:
    """
    Build the canonical Sentinel event payload.
    """

    timestamp = datetime.now(timezone.utc)

    confidence = 0.0

    if detections:
        confidence = max(
            float(detection.get("confidence", 0.0))
            for detection in detections
        )

    active_tracks = {
        detection["track_id"]
        for detection in detections
        if detection.get("track_id") is not None
    }

    metadata = {
        "node_name": config.node.name,
        "city": config.node.city,
        "source": str(camera.source),
        "tracking": {
            "tracker": config.inference.tracker,
            "active_tracks": len(active_tracks),
        },
    }

    if metadata_extra:
        metadata.update(metadata_extra)

    return {
        "event_id": str(uuid.uuid4()),
        "node_id": config.node.id,
        "camera_id": camera.id,
        "event_type": event_type,
        "timestamp": timestamp.isoformat(),
        "confidence": confidence,
        "latitude": config.node.latitude,
        "longitude": config.node.longitude,
        "frame_number": frame_number,
        "inference_latency_ms": round(latency_ms, 2),
        "detections": detections,
        "metadata": metadata,
    }


# ============================================================
# BEHAVIOR EVENT DEDUPLICATOR
# ============================================================

class BehaviorEventDeduplicator:
    """
    Prevent repeated behavior alerts for the same:

        camera + track + behavior

    until the cooldown expires.
    """

    def __init__(self, cooldown_seconds: float = 10.0):

        if cooldown_seconds < 0:
            raise ValueError(
                "cooldown_seconds must be >= 0"
            )

        self.cooldown_seconds = float(cooldown_seconds)

        self._last_emitted: dict[
            tuple[str, int, str],
            datetime,
        ] = {}

    def should_emit(
        self,
        camera_id: str,
        track_id: int,
        behavior: str,
        timestamp: datetime,
    ) -> bool:

        key = (
            str(camera_id),
            int(track_id),
            str(behavior),
        )

        previous = self._last_emitted.get(key)

        # First occurrence
        if previous is None:
            self._last_emitted[key] = timestamp
            return True

        elapsed = (
            timestamp - previous
        ).total_seconds()

        # Cooldown expired
        if elapsed >= self.cooldown_seconds:
            self._last_emitted[key] = timestamp
            return True

        return False

    def clear(self) -> None:
        self._last_emitted.clear()


# ============================================================
# BEHAVIOR CONFIGURATION
# ============================================================

def build_behavior_config(config) -> BehaviorConfig:
    """
    Convert Sentinel YAML/Pydantic behavior settings
    into BehaviorEngine configuration.
    """

    behavior = getattr(config, "behavior", None)

    if behavior is None:
        logger.warning(
            "Behavior configuration not found. "
            "Using BehaviorConfig defaults."
        )

        return BehaviorConfig()

    return BehaviorConfig(

        # Loitering
        loitering_enabled=(
            behavior.loitering.enabled
        ),

        loitering_min_duration_seconds=(
            behavior.loitering.min_duration_seconds
        ),

        loitering_max_movement_px=(
            behavior.loitering.max_movement_px
        ),

        loitering_max_speed_px_s=(
            behavior.loitering.max_speed_px_s
        ),

        # Suspicious stop
        suspicious_stop_enabled=(
            behavior.suspicious_stop.enabled
        ),

        suspicious_stop_min_duration_seconds=(
            behavior.suspicious_stop.min_duration_seconds
        ),

        suspicious_stop_max_speed_px_s=(
            behavior.suspicious_stop.max_speed_px_s
        ),

        # Rapid movement
        rapid_movement_enabled=(
            behavior.rapid_movement.enabled
        ),

        rapid_movement_speed_threshold_px_s=(
            behavior.rapid_movement.speed_threshold_px_s
        ),

        # Direction change
        direction_change_enabled=(
            behavior.abnormal_direction_change.enabled
        ),

        direction_change_angle_threshold_degrees=(
            behavior.abnormal_direction_change.angle_threshold_degrees
        ),

        direction_change_min_speed_px_s=(
            behavior.abnormal_direction_change.min_speed_px_s
        ),

        # General
        minimum_observations=(
            behavior.minimum_observations
        ),
    )


# ============================================================
# DECISION CONFIGURATION
# ============================================================

def build_decision_config(config) -> DecisionConfig:
    """
    Convert Sentinel YAML/Pydantic decision settings
    into DecisionEngine configuration.
    """

    decision = getattr(config, "decision", None)

    if decision is None:

        logger.warning(
            "Decision configuration not found. "
            "Using DecisionConfig defaults."
        )

        return DecisionConfig()

    return DecisionConfig(

        enabled=decision.enabled,

        periodic_inference_seconds=(
            decision.periodic_inference_seconds
        ),

        analyze_new_tracks=(
            decision.analyze_new_tracks
        ),

        high_confidence_threshold=(
            decision.high_confidence_threshold
        ),

        rapid_movement_threshold_px_s=(
            decision.rapid_movement_threshold_px_s
        ),

        vehicle_types=tuple(
            decision.vehicle_types
        ),

        person_enabled=(
            decision.person_enabled
        ),

        behavior_priority_enabled=(
            decision.behavior_priority_enabled
        ),

        stable_track_observations=(
            decision.stable_track_observations
        ),
    )


# ============================================================
# BEHAVIOR PROCESSING
# ============================================================

def analyze_behaviors(
    camera,
    config,
    behavior_engine,
    behavior_deduplicator,
    state_manager,
    event_client,
    frame_number,
    latency_ms,
):
    """
    Analyze every active TrackState exactly once.

    Returns:

        behavior_events_sent
        behavior_events_by_track

    The second value is passed directly into the
    Decision Engine so that behavior analysis is not
    performed twice.
    """

    behavior_events_by_track = {}

    if not getattr(config, "behavior", None):
        return 0, behavior_events_by_track

    if not config.behavior.enabled:
        return 0, behavior_events_by_track

    timestamp = datetime.now(timezone.utc)

    events_sent = 0

    active_tracks = state_manager.snapshot()

    for track in active_tracks:

        track_id = getattr(
            track,
            "track_id",
            None,
        )

        if track_id is None:
            continue

        # --------------------------------------------------------
        # Analyze behavior ONCE
        # --------------------------------------------------------

        try:

            behavior_events = (
                behavior_engine.analyze(track)
            )

        except Exception:

            logger.exception(
                "[%s] Behavior analysis failed | track=%s",
                camera.id,
                track_id,
            )

            continue

        # Store events for Decision Engine
        behavior_events_by_track[int(track_id)] = (
            behavior_events
        )

        if not behavior_events:
            continue

        # --------------------------------------------------------
        # Emit behavior events
        # --------------------------------------------------------

        for behavior_event in behavior_events:

            try:

                behavior_track_id = int(
                    behavior_event.track_id
                )

                # Deduplication
                if not behavior_deduplicator.should_emit(
                    camera_id=camera.id,
                    track_id=behavior_track_id,
                    behavior=behavior_event.behavior,
                    timestamp=timestamp,
                ):
                    continue

                # Metadata
                behavior_metadata = {
                    "behavior": (
                        behavior_event.to_dict()
                    ),
                    "behavior_engine": {
                        "version": "2.2",
                    },
                }

                # Build event
                event = build_event(
                    camera=camera,
                    config=config,
                    event_type="BEHAVIOR_DETECTED",
                    detections=[
                        {
                            "object_type": (
                                behavior_event.object_type
                            ),
                            "confidence": (
                                behavior_event.score / 100.0
                            ),
                            "track_id": behavior_track_id,
                        }
                    ],
                    frame_number=frame_number,
                    latency_ms=latency_ms,
                    metadata_extra=behavior_metadata,
                )

                # Send event
                sent = event_client.send(event)

                if sent:

                    events_sent += 1

                    logger.warning(
                        "[%s] Behavior detected | "
                        "track=%s | "
                        "behavior=%s | "
                        "severity=%s | "
                        "score=%s",
                        camera.id,
                        behavior_track_id,
                        behavior_event.behavior,
                        behavior_event.severity,
                        behavior_event.score,
                    )

            except Exception:

                logger.exception(
                    "[%s] Failed to emit behavior event",
                    camera.id,
                )

    return events_sent, behavior_events_by_track


# ============================================================
# DECISION PROCESSING
# ============================================================

def process_decisions(
    camera,
    state_manager,
    decision_engine,
    behavior_events_by_track,
    confidence_by_track,
):
    """
    Run the Phase 2.3 Decision Engine.

    The Decision Engine does NOT execute Local AI or Cloud AI.

    It only decides:

        SKIP
        LOCAL_AI
        CLOUD_AI

    based on:

        - new tracks
        - behavior
        - confidence
        - movement
        - periodic analysis
        - stable tracks
    """

    decisions = []

    active_tracks = state_manager.snapshot()

    for track in active_tracks:

        track_id = getattr(
            track,
            "track_id",
            None,
        )

        if track_id is None:
            continue

        try:

            confidence = confidence_by_track.get(
                int(track_id),
                0.0,
            )

            behavior_events = (
                behavior_events_by_track.get(
                    int(track_id),
                    [],
                )
            )

            decision = decision_engine.decide(
                track=track,
                behavior_events=behavior_events,
                confidence=confidence,
            )

            decisions.append(decision)

            logger.info(
                "[%s] AI decision | "
                "track=%s | "
                "object=%s | "
                "action=%s | "
                "priority=%s | "
                "reason=%s | "
                "confidence=%.2f",
                camera.id,
                track_id,
                getattr(
                    track,
                    "object_type",
                    "unknown",
                ),
                decision.action.value,
                decision.priority.value,
                decision.reason,
                confidence,
            )

        except Exception:

            logger.exception(
                "[%s] Decision analysis failed | track=%s",
                camera.id,
                track_id,
            )

    return decisions


# ============================================================
# CAMERA PROCESSING
# ============================================================

def process_camera(
    camera,
    config,
    tracker,
    event_client,
):
    """
    Complete Edge processing pipeline.

    Camera
       ↓
    YOLO + ByteTrack
       ↓
    TrackStateManager
       ↓
    Behavior Engine
       ↓
    Decision Engine
       ↓
    OBJECT_TRACKED / BEHAVIOR_DETECTED
    """

    logger.info(
        "[%s] Starting camera: %s",
        camera.id,
        camera.source,
    )

    # --------------------------------------------------------
    # Camera
    # --------------------------------------------------------

    stream = CameraStream(camera.source)
    stream.open()

    # --------------------------------------------------------
    # Tracking State
    # --------------------------------------------------------

    state_manager = TrackStateManager(

        max_missing_frames=(
            config.inference.max_missing_frames
        ),

        event_update_interval_seconds=(
            config.inference.event_update_interval_seconds
        ),

        min_track_observations=(
            config.inference.min_track_observations
        ),
    )

    # --------------------------------------------------------
    # Behavior Engine
    # --------------------------------------------------------

    behavior_enabled = (
        getattr(config, "behavior", None) is not None
        and config.behavior.enabled
    )

    behavior_engine = None

    behavior_deduplicator = None

    if behavior_enabled:

        behavior_config = build_behavior_config(
            config
        )

        behavior_engine = BehaviorEngine(
            config=behavior_config
        )

        behavior_deduplicator = (
            BehaviorEventDeduplicator(
                cooldown_seconds=10.0
            )
        )

        logger.info(
            "[%s] Behavior Engine enabled",
            camera.id,
        )

    else:

        logger.info(
            "[%s] Behavior Engine disabled",
            camera.id,
        )

    # --------------------------------------------------------
    # Decision Engine
    # --------------------------------------------------------

    decision_enabled = (
        getattr(config, "decision", None) is not None
        and config.decision.enabled
    )

    decision_engine = None

    if decision_enabled:

        decision_config = build_decision_config(
            config
        )

        decision_engine = DecisionEngine(
            config=decision_config
        )

        logger.info(
            "[%s] Decision Engine enabled | "
            "periodic=%ss | "
            "new_tracks=%s | "
            "high_confidence=%.2f",
            camera.id,
            decision_config.periodic_inference_seconds,
            decision_config.analyze_new_tracks,
            decision_config.high_confidence_threshold,
        )

    else:

        logger.info(
            "[%s] Decision Engine disabled",
            camera.id,
        )

    # --------------------------------------------------------
    # Counters
    # --------------------------------------------------------

    frame_number = 0

    events_sent = 0

    behavior_events_sent = 0

    decision_counts = {
        "evaluated": 0,
        "skip": 0,
        "local_ai": 0,
        "cloud_ai": 0,
    }

    # ========================================================
    # CAMERA LOOP
    # ========================================================

    try:

        while True:

            # ------------------------------------------------
            # Read frame
            # ------------------------------------------------

            success, frame = stream.read()

            if not success:

                logger.info(
                    "[%s] Stream ended",
                    camera.id,
                )

                break

            frame_number += 1

            # ------------------------------------------------
            # Frame sampling
            # ------------------------------------------------

            if (
                frame_number
                % config.inference.track_every_n_frames
                != 0
            ):
                continue

            # ------------------------------------------------
            # YOLO + ByteTrack
            # ------------------------------------------------

            detections, latency_ms = tracker.track(
                frame
            )

            timestamp = datetime.now(timezone.utc)

            # ------------------------------------------------
            # Update TrackState
            # ------------------------------------------------

            enriched_detections = (
                state_manager.update(
                    detections,
                    timestamp,
                )
            )

            if not enriched_detections:
                continue

            # =================================================
            # CONFIDENCE MAP
            # =================================================

            confidence_by_track = {}

            for detection in enriched_detections:

                track_id = detection.get(
                    "track_id"
                )

                if track_id is None:
                    continue

                confidence_by_track[int(track_id)] = (
                    float(
                        detection.get(
                            "confidence",
                            0.0,
                        )
                    )
                )

            # =================================================
            # BEHAVIOR ANALYSIS
            # =================================================

            behavior_events_by_track = {}

            if (
                behavior_enabled
                and behavior_engine is not None
                and behavior_deduplicator is not None
            ):

                (
                    behavior_sent,
                    behavior_events_by_track,
                ) = analyze_behaviors(

                    camera=camera,

                    config=config,

                    behavior_engine=(
                        behavior_engine
                    ),

                    behavior_deduplicator=(
                        behavior_deduplicator
                    ),

                    state_manager=(
                        state_manager
                    ),

                    event_client=(
                        event_client
                    ),

                    frame_number=(
                        frame_number
                    ),

                    latency_ms=(
                        latency_ms
                    ),
                )

                behavior_events_sent += (
                    behavior_sent
                )

            # =================================================
            # DECISION ENGINE
            # =================================================

            if (
                decision_enabled
                and decision_engine is not None
            ):

                decisions = process_decisions(

                    camera=camera,

                    state_manager=(
                        state_manager
                    ),

                    decision_engine=(
                        decision_engine
                    ),

                    behavior_events_by_track=(
                        behavior_events_by_track
                    ),

                    confidence_by_track=(
                        confidence_by_track
                    ),
                )

                # --------------------------------------------
                # Decision metrics
                # --------------------------------------------

                for decision in decisions:

                    decision_counts[
                        "evaluated"
                    ] += 1

                    action = (
                        decision.action.value
                    )

                    if action == "SKIP":

                        decision_counts[
                            "skip"
                        ] += 1

                    elif action == "LOCAL_AI":

                        decision_counts[
                            "local_ai"
                        ] += 1

                    elif action == "CLOUD_AI":

                        decision_counts[
                            "cloud_ai"
                        ] += 1

            # =================================================
            # OBJECT TRACKING EVENT
            # =================================================

            emit_detections = []

            for detection in enriched_detections:

                track_id = detection.get(
                    "track_id"
                )

                if track_id is None:
                    continue

                if state_manager.should_emit_update(
                    track_id,
                    timestamp,
                ):

                    emit_detections.append(
                        detection
                    )

            if not emit_detections:
                continue

            # ------------------------------------------------
            # Build object event
            # ------------------------------------------------

            event = build_event(

                camera=camera,

                config=config,

                event_type="OBJECT_TRACKED",

                detections=(
                    emit_detections
                ),

                frame_number=(
                    frame_number
                ),

                latency_ms=(
                    latency_ms
                ),
            )

            # ------------------------------------------------
            # Send
            # ------------------------------------------------

            sent = event_client.send(event)

            if sent:

                events_sent += 1

                logger.info(
                    "[%s] Track event sent | "
                    "tracks=%d | "
                    "active=%d | "
                    "latency=%.2fms",
                    camera.id,
                    len(emit_detections),
                    state_manager.active_count(),
                    latency_ms,
                )

    except KeyboardInterrupt:

        logger.info(
            "[%s] Camera processing interrupted",
            camera.id,
        )

    except Exception:

        logger.exception(
            "[%s] Camera processing failed",
            camera.id,
        )

    finally:

        # ----------------------------------------------------
        # Cleanup
        # ----------------------------------------------------

        stream.release()

        state_manager.reset()

        tracker.reset()

        if behavior_deduplicator is not None:
            behavior_deduplicator.clear()

        logger.info(
            "[%s] Camera stopped | "
            "frames=%d | "
            "object_events=%d | "
            "behavior_events=%d | "
            "decisions=%d | "
            "skip=%d | "
            "local_ai=%d | "
            "cloud_ai=%d",
            camera.id,
            frame_number,
            events_sent,
            behavior_events_sent,
            decision_counts["evaluated"],
            decision_counts["skip"],
            decision_counts["local_ai"],
            decision_counts["cloud_ai"],
        )


# ============================================================
# MAIN
# ============================================================

def main():

    setup_logging()

    config = load_config()

    logger.info(
        "===================================="
    )

    logger.info(
        "Sentinel Edge Node Starting"
    )

    logger.info(
        "Node: %s",
        config.node.id,
    )

    logger.info(
        "City: %s",
        config.node.city,
    )

    logger.info(
        "Tracker: %s",
        config.inference.tracker,
    )

    # --------------------------------------------------------
    # Behavior status
    # --------------------------------------------------------

    behavior_enabled = (
        getattr(config, "behavior", None) is not None
        and config.behavior.enabled
    )

    logger.info(
        "Behavior Engine: %s",
        (
            "ENABLED"
            if behavior_enabled
            else "DISABLED"
        ),
    )

    # --------------------------------------------------------
    # Decision status
    # --------------------------------------------------------

    decision_enabled = (
        getattr(config, "decision", None) is not None
        and config.decision.enabled
    )

    logger.info(
        "Decision Engine: %s",
        (
            "ENABLED"
            if decision_enabled
            else "DISABLED"
        ),
    )

    logger.info(
        "===================================="
    )

    # --------------------------------------------------------
    # Event Client
    # --------------------------------------------------------

    event_client = EventClient(
        config.api.base_url
    )

    try:

        for camera in config.cameras:

            if not camera.enabled:
                continue

            # ------------------------------------------------
            # Separate tracker per camera
            # ------------------------------------------------

            tracker = VehicleTracker(

                model_path=(
                    config.inference.model_path
                ),

                confidence=(
                    config.inference.confidence
                ),

                classes=(
                    config.inference.classes
                ),

                tracker=(
                    config.inference.tracker
                ),

                image_size=(
                    config.inference.image_size
                ),
            )

            # ------------------------------------------------
            # Process camera
            # ------------------------------------------------

            process_camera(

                camera=camera,

                config=config,

                tracker=tracker,

                event_client=event_client,
            )

    finally:

        event_client.close()

        logger.info(
            "Sentinel Edge Node stopped"
        )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()